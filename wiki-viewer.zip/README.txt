A Pen created at CodePen.io. You can find this one at http://codepen.io/lalawow/pen/eJroNg.

 A Free Code Camp project