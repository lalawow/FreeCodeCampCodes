 $(document).ready(function(){
    showQuote()
   $("#new-quote").click(function() {
     showQuote()
   })
 })
 
var quotes = [
{
quote: "I only sing in the shower. I would join a choir, but I don’t think my bathtub can hold that many people.",
author: "Jarod Kintz"
},
{
quote: "Like Alexander the Great and Caesar, I’m out to conquer the world. But first I have to stop at Walmart and pick up some supplies.",
author: "Jarod Kintz"
},
{
quote: "I love to talk about nothing. It's the only thing I know anything about.",
author: "Oscar Wilde"
},
{
quote: 'I went to a restaurant that serves "breakfast at any time" so I ordered French toast during the Renaissance.',
author: "Steven Wright"
},
{
quote: "The scientific theory I like best is that the rings of Saturn are composed entirely of lost airline luggage.",
author: "Mark Russell"
},
{
quote: "Friendship is like peeing on yourself: everyone can see it, but only you get the warm feeling that it brings.",
author: "Robert Bloch"
},
{
quote: "First the doctor told me the good news: I was going to have a disease named after me.",
author: "Steve Martin"
},
{
quote: "My therapist told me the way to achieve true inner peace is to finish what I start. So far I’ve finished two bags of M&Ms and a chocolate cake. I feel better already.",
author: "Dave Barry"
},
{
quote: "Insanity is hereditary. You get it from your children.",
author: "Sam Levenson"
},
{
quote: "An archaeologist is the best husband a woman can have; the older she gets the more interested he is in her.",
author: "Agatha Christie"
},
{
quote: "Housework can’t kill you, but why take a chance?",
author: "Phyllis Diller"
},
{
quote: "To attract men, I wear a perfume called New Car Interior.",
author: "Rita Rudner"
},
{
quote: "Two things are infinite, the universe and human stupidity, and I am not yet completely sure about the universe.",
author: "Albert Einstein"
},
{
quote: "If you think nobody cares if you’re alive, try missing a couple of car payments.",
author: "Flip Wilson"
},
{
quote: "Some cause happiness wherever they go; others, whenever they go.",
author: "Oscar Wilde"
},
{
quote: "The human brain is a wonderful thing. It starts working the moment you are born, and never stops until you stand up to speak in public.",
author: "George Jessel"
},
{
quote: "I told my wife the truth. I told her I was seeing a psychiatrist. Then she told me the truth: that she was seeing a psychiatrist, two plumbers, and a bartender.",
author: "Rodney Dangerfield"
},
{
quote: "If a book about failures doesn't sell, is it a success?",
author: "Jerry Seinfeld"
},
{
quote: "Money can’t buy happiness, but it sure makes misery easier to live with.",
author: "Anonymous"
},
{
quote: "Each time history repeats itself, the price goes up.",
author: "Ronald Wright."
}]

 var showQuote = function() {
   var quoteNum = Math.floor(Math.random()*20)
   $("#quote-text").text(quotes[quoteNum]["quote"])
   $("#quote-author").text(quotes[quoteNum]["author"])
 }