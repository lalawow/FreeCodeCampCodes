A Pen created at CodePen.io. You can find this one at http://codepen.io/lalawow/pen/MKQGMz.

 A free code camp project which shows camper news use a free code camp API