A Pen created at CodePen.io. You can find this one at http://codepen.io/lalawow/pen/EPQvbr.

 A Free Code Camp project which can show local weather status.